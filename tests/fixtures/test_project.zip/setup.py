from setuptools import setup
setup(name="testproject")
